<?php
/**
 * Dailer FullCalender Plugin.
 *
 * @copyright Copyright (C) 2018, contact - http://twitter.com/shuklashaunak
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License, version 3 or higher
 *
 * @wordpress-plugin
 * Plugin Name: Dailer Fullcalendar
 * Version:     1.0.0
 * Plugin URI:  http://dailer.com/
 * Description: Custom FullCalendar for Dailer.
 * Author:      Dailer
 * Author URI:  http://www.dailer.com
 * License:     GPL v3
 *
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Plugin constants
 */
if(!defined('DFC_PLUGIN_VERSION'))
	define('DFC_PLUGIN_VERSION', '2.0.0');
if(!defined('DFC_URL'))
	define('DFC_URL', plugin_dir_url( __FILE__ ));
if(!defined('DFC_PATH'))
	define('DFC_PATH', plugin_dir_path( __FILE__ ));


/*
 * Main class
 */
/**
 * Class Dailer
 *
 * This class creates the option page and add the web app script
 */
class Dailer
{
	 /**
	 * The security nonce
	 *
	 * @var string
	 */
	private $_nonce = 'dailer_admin';
        
		
	public function __construct()
	{
		// Admin page calls
		add_action('admin_menu',                array($this,'addAdminMenu'));
		add_action('wp_ajax_store_admin_data',  array($this,'storeAdminData'));
		add_action('admin_enqueue_scripts',     array($this,'addAdminScripts'));
		add_shortcode('dailer_calendar', array($this,'calendar'));
    }
        
	/**
	 * Adds Admin Scripts for the Ajax call
	 */
	public function addAdminScripts()
	{

		$admin_options = array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'_nonce'   => wp_create_nonce( $this->_nonce ),
		);

		wp_localize_script('dailer-admin', 'dailer_exchanger', $admin_options);

	}
    /**
	 * Returns the calendar HTML setup and primes the js to load at wp_footer
	 * @param array $args
	 * @return string
	 */
	 public function calendar(){
		$response =  $this->getData(2);
		$eventData = json_decode($response['body']);
		//print_r(json_decode($response['body'])); exit;
		$head = "<link href='".DFC_URL."fullcalendar.min.css' rel='stylesheet' />
		<link href='".DFC_URL."fullcalendar.print.min.css' rel='stylesheet' media='print' />
		<script src='".DFC_URL."lib/moment.min.js'></script>
		<script src='".DFC_URL."lib/jquery.min.js'></script>
		<script src='".DFC_URL."fullcalendar.min.js'></script>";
		$head .= "<script>

  $(document).ready(function() {

    $('#calendar').fullCalendar({
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'agendaWeek,agendaDay'
      },
      defaultDate: '2019-01-12',
      navLinks: true, // can click day/week names to navigate views
      selectable: true,
      selectHelper: true,
	  defaultView: 'agendaWeek',
      select: function(start, end) {
        var title = prompt('Event Title:');
        var eventData;
        if (title) {
          eventData = {
            title: title,
            start: start,
            end: end
          };
          $('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true
        }
        $('#calendar').fullCalendar('unselect');
      },
      editable: true,
      eventLimit: true, // allow more link when too many events
	  
      events: [";
	  $new_event = "";
		foreach($eventData->calendar_details as $event_id =>$data ){
			$new_event .= "{title:'".$data->title."',url: '".$data->url."',start:'".str_replace(' ','T',str_replace('.000000','',$data->start->date))."',end:'".str_replace(' ','T',str_replace('.000000','',$data->end->date))."'},";
		}
        
      $head .= $new_event."]
    });

  });

</script>";
$head .= "<div id='calendar'></div>";
echo $head;
	 }
    
        
    /**
	 * Adds the dailer label to the WordPress Admin Sidebar Menu
	 */
	public function addAdminMenu()
	{
		add_menu_page(
				__( 'Dailer', 'dailer' ),
				__( 'Dailer', 'dailer' ),
				'manage_options',
				'dailer',
				array($this, 'adminLayout'),
				'dashicons-dashboard'
		);
	}
        
	/**
	 * Outputs the Admin Dashboard layout containing the form with all its options
	 *
	 * @return void
	 */
	public function adminLayout()
	{

		?>

	<div class="wrap">

		<h1><?php _e('Dailer FullCalendar Description', 'dailer'); ?></h1>

		
		<form id="dailer-admin-form" class="postbox">

			<div class="form-group inside">

				<?php
				/*
				 * --------------------------
				 * Shortcode Description
				 * --------------------------
				 */
				?>

				<h3>
					
					<?php _e('Shortcode', 'dailer'); ?>
				</h3>
				<p>[dailer_calendar]</p>
			</div>

		</form>

	</div>

	<?php

	}
        
	/**
	 * Returns the saved options data as an array
     *
     * @return array
	 */
	private function getData($timezone)
    {
	    return $request = wp_remote_get( 'http://localhost/dailer/public/api/calendarapi?timezone='.$timezone );
    }
    
    /**
	 * Callback for the Ajax request
	 *
	 * Updates the options data
     *
     * @return void
	 */
	public function storeAdminData()
    {

		if (wp_verify_nonce($_POST['security'], $this->_nonce ) === false)
			die('Invalid Request! Reload your page please.');

		update_option($this->dailer_gtm_status, $_POST['dailer_gtm_status']);
        update_option($this->dailer_gtm_container, strtoupper($_POST['dailer_gtm_container']));
        update_option($this->dailer_gtm_datalayer_name, $_POST['dailer_gtm_datalayer_name']);
        update_option($this->dailer_gtm_woo, $_POST['dailer_gtm_woo']);
        update_option($this->dailer_gtm_cf7, $_POST['dailer_gtm_cf7']);

		echo __('Saved!', 'dailer');
		die();

	}
    
        
}

/*
 * Starts our plugin class, easy!
 */
new Dailer();

